#ifndef _BITS_SANBOOT_H
#define _BITS_SANBOOT_H

/** @file
 *
 * x86_64-specific sanboot API implementations
 *
 */

FILE_LICENCE ( GPL2_OR_LATER );

#endif /* _BITS_SANBOOT_H */
