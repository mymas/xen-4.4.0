#ifndef _IPXE_TIMER2_H
#define _IPXE_TIMER2_H

/** @file
 *
 * Timer chip control
 *
 */

FILE_LICENCE ( GPL2_OR_LATER );

extern void timer2_udelay ( unsigned long usecs );

#endif /* _IPXE_TIMER2_H */
